/*
*  Daniel Henrique Lelis de Almeida - 12543822
*/

#pragma once

void readline(char *string);
void print_autocorrection_checksum(char *nomeArquivoBinario);
void scan_quote_string(char *str);